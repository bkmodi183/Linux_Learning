#!/bin/bash

echo "Hello this is my first script"
