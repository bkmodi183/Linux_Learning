#1/bin/bash

cloud="AWS"
environment="Dev"

echo "This is $cloud cloud, and we're working on $environment envirment"

echo "This is $SHELL"

echo "This is $HOME"

echo " Todays date is $(date)"
