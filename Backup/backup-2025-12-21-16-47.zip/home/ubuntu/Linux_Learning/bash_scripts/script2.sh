#!/bin/bash

mkdir -p new_folder
cd new_folder
touch new_file.txt
echo "this is new_file created through script" > new_file.txt
echo "The script executed successfully and a folder with name new_folder along with a text file inside the folder with name new_file created."
